﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;


public class EnemyGFX : MonoBehaviour
{
    public AIPath aiPath;
    
    public Animator frogAnimator;
    AIDestinationSetter myAIDestinationSetter;
        
    // Start is called before the first frame update
    void Start()
    {
        myAIDestinationSetter=GetComponentInParent<AIDestinationSetter>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(Mathf.Abs(aiPath.velocity.x) > 0)
        {
            frogAnimator.SetBool("frogMoving", true);
        } else
        {
            frogAnimator.SetBool("frogMoving", false);
        }
        if(aiPath.desiredVelocity.x >= 0.01f)
        {
            transform.localScale = new Vector3(-8f, 8f, 8f);

        } else if (aiPath.desiredVelocity.x <= -0.01f)
        {
            transform.localScale = new Vector3(8f, 8f, 8f);
        }

        
    }
    private void OnTriggerEnter2D(Collider2D findPlayer)
    {
        if(findPlayer.tag == "Player")
        {
            print("Colliding with player");
            myAIDestinationSetter.followThrough = true;
        } 
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        myAIDestinationSetter.followThrough = false;
    }
}
