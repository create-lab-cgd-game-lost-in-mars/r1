Export all to assets
First set a circle collider to your character
Have an animation to your enemy character
"PathScript" -> EnemyAnimation (drag the enemy animation prefab into the pathscript)
put "Astar Path", "AI Path", and "Ai Destination Setter".
- ill do most of the technical enemy stuff for you tmr

**MAKE SURE YOU HAVE AN IDLE AND WALKING ANIMATION
FOR YOUR ENEMY CHARACTER, MAKE SURE YOU HAVE AT LEAST
ONE, ILL DO IT FOR YOU WHEN YOU'RE GONE FOR THE TALKS**